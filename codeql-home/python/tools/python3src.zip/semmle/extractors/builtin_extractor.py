
import sys
from semmle import util
from semmle.python.passes.objects import ObjectPass
from semmle.extractors.base import BaseExtractor

class BuiltinExtractor(BaseExtractor):
    name = 'built-in extractor'

    def process(self, unit):
        if (not isinstance(unit, util.BuiltinModuleExtractable)):
            return NotImplemented
        name = util.unicode_to_str(unit.name, sys.getfilesystemencoding())
        module = __import__(name)
        writer = util.TrapWriter()
        ObjectPass().extract_builtin(module, writer)
        output = writer.get_compressed()
        self.trap_folder.write_trap('builtin', name, output)
        return ()

    def close(self):
        pass
